package gus06.framework;

public interface V {
    public void v(String key, Object obj) throws Exception;
}
