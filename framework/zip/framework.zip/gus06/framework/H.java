package gus06.framework;

public interface H {
    public double h(double value) throws Exception;
}