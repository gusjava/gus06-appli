package gus06.framework;

public interface P {   
    public void p(Object obj) throws Exception;
}