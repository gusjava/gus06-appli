package gus06.framework;

public interface R {  
    public Object r(String key) throws Exception;
}