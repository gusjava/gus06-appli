package gus06.framework;

import javax.swing.JComponent;

public interface I {    
    public JComponent i() throws Exception;
}
