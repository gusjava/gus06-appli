package gus06.framework;

public interface I {
    public Object i() throws Exception;
}