package gus06.framework;

public interface G {    
    public Object g() throws Exception;
}
