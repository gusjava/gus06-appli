package gus06.framework;

public interface Service extends Runnable, E, F, G, H, I, P, R, S, T, V {}