package gus06.framework;

public interface T {    
    public Object t(Object obj) throws Exception;
}