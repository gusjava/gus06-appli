package gus06.framework;

public interface E {
    public void e() throws Exception;
}