package gus06.framework;

public interface F {
    public boolean f(Object obj) throws Exception;
}
