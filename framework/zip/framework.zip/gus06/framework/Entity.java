package gus06.framework;


public interface Entity {

    public String creationDate();
}
